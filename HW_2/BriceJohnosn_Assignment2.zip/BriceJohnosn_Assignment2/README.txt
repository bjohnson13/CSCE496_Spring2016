See lines 31-39 for instruction for running:
	Fitness Function 1 or 2
	Original Algorithm
	Random Generations Experiment
	Experiments:
		Fixed Crossover Point
		Decreasing Mutation Rate

To compile from terminal
	javac GeneticAlgorithm.java

To run from terminal
	java GeneticAlgorithm