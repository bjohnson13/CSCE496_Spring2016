To compile:
	On command line, in directory with .java file
	javac sudoku.java

To run:
	On command line, in directory with .java file and input file
	java sudoku input.txt